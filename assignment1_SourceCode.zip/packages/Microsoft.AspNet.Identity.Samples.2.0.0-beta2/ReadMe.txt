Please see http://go.microsoft.com/fwlink/?LinkID=301950 for more information on using ASP.NET Identity.
About this sample
------------------------------------------------------------
This is a sample template which shows how you can do the most common scenarios in ASP.NET Identity such 
as Local Logins, Social Logins, Account Confirmation, Password Reset, Two-Factor Authentication and more.
For more information on how to configure this sample for these feature, please visit http://go.microsoft.com/fwlink/?LinkID=320973

Running this sample in your ASP.NET application
------------------------------------------------------------
This is a sample template so please install this in an empty ASP.NET project only. Installing this in an 
existing application will have some side effects as this sample configures OWIN middlewares in StartupAuth.cs 
and creates a database for storing membership information.
