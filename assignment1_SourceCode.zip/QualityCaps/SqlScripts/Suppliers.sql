﻿create table Suppliers(
ID int primary key identity(1,1),
Name nvarchar(160),
Number nvarchar(max),
Email nvarchar(max),
)